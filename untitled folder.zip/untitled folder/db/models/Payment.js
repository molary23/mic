const { DataTypes, Model } = require("sequelize");
sequelize = require("../../config/dbcon");

class Payment extends Model {}

Payment.init(
  {
    // Model attributes are defined here
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },

    amount: {
      type: DataTypes.DOUBLE, // Sub active or not
      allowNull: false,
    },
    reference: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("s", "f"), //successful,failed
      defaultValue: "s",
    },
    gateway: {
      type: DataTypes.ENUM("b", "c"), //Bank,Crypto
      allowNull: false,
    },
  },
  {
    // don't forget to enable timestamps!
    timestamps: true,

    // I want createdAt
    createdAt: true,
    // I want updatedAt
    updatedAt: true,
    // Other model options go here
    sequelize, // We need to pass the connection instance
    modelName: "Payment", // We need to choose the model name
  }
);
module.exports = Payment;
