module.exports = {
  secretOrKey: "MIC Earn Business by Molary",
  mailKey: "the greatest TO EVER DO it is Molary",
};
