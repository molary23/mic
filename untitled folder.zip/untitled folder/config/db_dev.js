const db_dev = {
  dbname: "mic",
  dbhost: "127.0.01",
  dbuser: "molary",
  dbpass: "7UCVG5Sr*fj483gH%",
};
module.exports = db_dev;
