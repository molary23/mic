module.exports = {
  secretOrKey: process.env.SECRET_OR_KEY,
  mailKey: process.env.EMAIL_KEY,
};
