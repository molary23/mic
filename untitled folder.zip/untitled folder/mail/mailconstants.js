const values = {
  date: new Date().getFullYear(),
  website: "www.somewhere.com",
  logo: "url",
  fb: "url",
  tw: "url",
  in: "url",
};

module.exports = values;
